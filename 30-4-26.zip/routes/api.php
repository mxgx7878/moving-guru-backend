<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\API\AuthController;
use App\Http\Controllers\API\ProfileController;
use App\Http\Controllers\API\PasswordResetController;
use App\Http\Controllers\API\ProfileViewController;
use App\Http\Controllers\API\GrowPostController;
use App\Http\Controllers\API\JobListingController;
use App\Http\Controllers\API\InstructorController;
use App\Http\Controllers\API\ReviewController;
use App\Http\Controllers\API\UserManagementController;
use App\Http\Controllers\API\PostController;
use App\Http\Controllers\API\AdminDashboardController;
use App\Http\Controllers\API\EmailBroadcastController;
use App\Http\Controllers\API\InstructorDashboardController;
use App\Http\Controllers\API\StudioDashboardController;
use App\Http\Controllers\API\SubscriptionController;
use App\Http\Controllers\API\PaymentController;
use App\Http\Controllers\API\PlanController;
use App\Http\Controllers\API\AdminPlanController;
use App\Http\Controllers\API\FeatureController;
use App\Http\Controllers\API\StripeWebhookController;

use App\Http\Middleware\IsAdmin;
use App\Http\Middleware\IsStudio;

Route::post('/register', [AuthController::class, 'register']);
Route::post('/login', [AuthController::class, 'login']);
Route::post('/password/forgot', [PasswordResetController::class, 'forgot']);
Route::post('/password/reset', [PasswordResetController::class, 'reset']);
Route::get('grow-posts',       [GrowPostController::class, 'index']);
Route::get('grow-posts/{id}',  [GrowPostController::class, 'show'])->whereNumber('id');
Route::get('jobs',            [JobListingController::class, 'index']);
Route::get('jobs/{id}',       [JobListingController::class, 'show'])->whereNumber('id');
Route::get('instructors',        [InstructorController::class, 'index']);

Route::get('users/{id}/reviews', [ReviewController::class, 'forUser'])->whereNumber('id');
Route::get('plans', [PlanController::class, 'index']);
Route::post('stripe/webhook', [StripeWebhookController::class, 'handle']);



Route::middleware('auth:sanctum')->group(function () {
  Route::post('/logout', [AuthController::class, 'logout']);
  Route::get('/me', [AuthController::class, 'me']);
  Route::post('/refresh', [AuthController::class, 'refresh']);
  Route::patch('/profile', [ProfileController::class, 'update']);
  Route::post('/password/change', [PasswordResetController::class, 'change']);

  // Profile Views
  Route::post('/profile/{userId}/view', [ProfileViewController::class, 'store']);
  Route::get('/profile/views', [ProfileViewController::class, 'index']);
  Route::get('/profile/views/analytics', [ProfileViewController::class, 'analytics']);
  // Grow Posts (instructor-facing)
  Route::get('grow-posts/my',        [GrowPostController::class, 'myPosts']);
  Route::post('grow-posts',           [GrowPostController::class, 'store']);
  Route::put('grow-posts/{id}',      [GrowPostController::class, 'update']);
  Route::delete('grow-posts/{id}',      [GrowPostController::class, 'destroy']);
  //JOB LISTINGS & APPLICATIONS
  Route::get('jobs/mine',       [JobListingController::class, 'mine'])
    ->middleware(IsStudio::class);
  Route::post('jobs/{id}/apply',   [JobListingController::class, 'apply'])->whereNumber('id');
  Route::get('applications/mine', [JobListingController::class, 'myApplications']);
  Route::delete('applications/{id}', [JobListingController::class, 'withdraw'])->whereNumber('id');
  Route::get('me/instructors', [InstructorController::class, 'index']);
  Route::get('instructors/{id}',   [InstructorController::class, 'show'])->whereNumber('id');


  Route::get('instructors/saved',  [InstructorController::class, 'saved'])
    ->middleware(IsStudio::class);


  Route::post('reviews',           [ReviewController::class, 'store']);
  Route::delete('reviews/{id}',      [ReviewController::class, 'destroy'])->whereNumber('id');
  Route::get('reviews/mine',      [ReviewController::class, 'mine']);
  Route::get('reviews/eligible',  [ReviewController::class, 'eligible']);

  Route::get('posts',      [PostController::class, 'index']);
  Route::get('posts/{id}', [PostController::class, 'show'])->whereNumber('id');
  Route::post('users/run-stale-sweep', [UserManagementController::class, 'runStaleSweep']);
  Route::get('dashboard/instructor', [InstructorDashboardController::class, 'index']);

  

    // Subscriptions
  Route::get  ('subscription',                 [SubscriptionController::class, 'show']);
  Route::post ('subscription/setup-intent',    [SubscriptionController::class, 'setupIntent']);
  Route::post ('subscription/payment-method',  [SubscriptionController::class, 'attachPaymentMethod']);
  Route::post ('subscription/change',          [SubscriptionController::class, 'change']);
  Route::post ('subscription/cancel',          [SubscriptionController::class, 'cancel']);
  Route::post ('subscription/resume',          [SubscriptionController::class, 'resume']);

  // Payments
  Route::get  ('payments',              [PaymentController::class, 'index']);
  Route::get  ('payments/{id}/invoice', [PaymentController::class, 'invoice']);

});

Route::middleware(['auth:sanctum', IsStudio::class])->group(function () {
  Route::post('jobs',                    [JobListingController::class, 'store']);
  Route::patch('jobs/{id}',               [JobListingController::class, 'update'])->whereNumber('id');
  Route::delete('jobs/{id}',               [JobListingController::class, 'destroy'])->whereNumber('id');
  Route::get('jobs/{id}/applicants',    [JobListingController::class, 'applicants'])->whereNumber('id');
  Route::patch('applications/{id}/status', [JobListingController::class, 'updateApplicationStatus'])->whereNumber('id');
  Route::post('instructors/save',   [InstructorController::class, 'save']);
  Route::post('instructors/unsave', [InstructorController::class, 'unsave']);
  Route::get('dashboard/studio',     [StudioDashboardController::class,    'index']);
});

Route::middleware(['auth:sanctum', IsAdmin::class])->prefix('admin')->group(function () {
  Route::get('grow-posts',              [GrowPostController::class, 'adminIndex']);
  Route::patch('grow-posts/{id}/approve', [GrowPostController::class, 'approve']);
  Route::patch('grow-posts/{id}/reject',  [GrowPostController::class, 'reject']);
  Route::patch('grow-posts/{id}/boost',   [GrowPostController::class, 'boost']);
  Route::delete('grow-posts/{id}',         [GrowPostController::class, 'adminDestroy']);
  Route::get('users',                   [UserManagementController::class, 'index']);
  Route::post('users',                   [UserManagementController::class, 'store']);
  Route::get('users/{id}',              [UserManagementController::class, 'show'])->whereNumber('id');
  Route::patch('users/{id}',              [UserManagementController::class, 'update'])->whereNumber('id');
  Route::patch('users/{id}/approve',      [UserManagementController::class, 'approve'])->whereNumber('id');
  Route::patch('users/{id}/reject',       [UserManagementController::class, 'reject'])->whereNumber('id');
  Route::patch('users/{id}/suspend',      [UserManagementController::class, 'suspend'])->whereNumber('id');
  Route::patch('users/{id}/activate',     [UserManagementController::class, 'activate'])->whereNumber('id');
  Route::patch('users/{id}/verify',       [UserManagementController::class, 'verify'])->whereNumber('id');
  Route::delete('users/{id}',              [UserManagementController::class, 'destroy'])->whereNumber('id');

  Route::get('jobs',                 [JobListingController::class, 'index']);           // ← reuse
  Route::get('jobs/{id}',            [JobListingController::class, 'show'])->whereNumber('id');           // ← reuse
  Route::get('jobs/{id}/applicants', [JobListingController::class, 'applicants'])->whereNumber('id');     // ← reuse (refactored)
  Route::patch('jobs/{id}/activate',   [JobListingController::class, 'adminActivate'])->whereNumber('id');
  Route::patch('jobs/{id}/deactivate', [JobListingController::class, 'adminDeactivate'])->whereNumber('id');
  Route::delete('jobs/{id}',            [JobListingController::class, 'adminDestroy'])->whereNumber('id');
  Route::get('reviews', [ReviewController::class, 'adminIndex']);

  Route::get('posts',                  [PostController::class, 'adminIndex']);
  Route::post('posts',                  [PostController::class, 'store']);
  Route::put('posts/{id}',             [PostController::class, 'update'])->whereNumber('id');
  Route::delete('posts/{id}',             [PostController::class, 'destroy'])->whereNumber('id');
  Route::patch('posts/{id}/publish',     [PostController::class, 'publish'])->whereNumber('id');
  Route::patch('posts/{id}/unpublish',   [PostController::class, 'unpublish'])->whereNumber('id');
  Route::get('dashboard/stats',    [AdminDashboardController::class, 'stats']);
  Route::get('dashboard/activity', [AdminDashboardController::class, 'activity']);
  Route::get('dashboard/revenue', [AdminDashboardController::class, 'revenue']);
  Route::get ('emails/audience-counts', [EmailBroadcastController::class, 'audienceCounts']);
  Route::post('emails/broadcast',       [EmailBroadcastController::class, 'send']);
  Route::get   ('plans',       [AdminPlanController::class, 'index']);
  Route::post  ('plans',       [AdminPlanController::class, 'store']);
  Route::patch ('plans/{id}',  [AdminPlanController::class, 'update']);
  Route::delete('plans/{id}',  [AdminPlanController::class, 'destroy']);

  Route::get('features', [FeatureController::class, 'index']);
  Route::get  ('plans/{id}/features', [AdminPlanController::class, 'showFeatures']);
  Route::patch('plans/{id}/features', [AdminPlanController::class, 'updateFeatures']);
  Route::post('plans/sync-from-stripe', [AdminPlanController::class, 'syncFromStripe']);

});
